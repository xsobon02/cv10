﻿CREATE SERVICE [Service1]
	ON QUEUE [SomeSchema].[SomeQueue]
	(
		[SomeContract]
	)
